@extends('layouts.main')

@section('content')
    
<h1> Beranda Saya</h1>

  @endsection