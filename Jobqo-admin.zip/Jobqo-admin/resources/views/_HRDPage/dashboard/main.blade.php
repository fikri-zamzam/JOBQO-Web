@extends('layouts.main')

@section('content')
    
<h1> Beranda Saya HRD Perusahaan {{ $company }} </h1>

  @endsection