
<link rel="stylesheet" href="{{ asset('public_assets/vendors/bootstrap/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('public_assets/vendors/boxicons-2.1.2/css/boxicons.min.css') }}">
<link rel="stylesheet" href="{{ asset('public_assets/styles/style.css') }}">
