

<?php $__env->startSection('content'); ?>
    
<table class="table mt-3">
    <thead class="table-dark">
      <th>Kode Perusahaan</th>
      <th>Nama Perusahaan</th>
      <th>Kontak</th>
      <th>Bidang </th>
      <th>Jenis</th>
      <th>Aksi</th>
    </thead>
    <tbody>
      <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td scope="row"> <?php echo e($value->id); ?> </td>
        <td> <?php echo e($value->name_company); ?> </td>
        <td> <?php echo e($value->contact); ?> </td>
        <td> <?php echo e($value->Sectors->nameSector); ?> </td>
        <td> <?php echo e($value->Types->nameType); ?> </td>
        <td>
          <div class="row">
            <div class="col-3">
                <form action="<?php echo e(url('admin/verifycompany/'.$value->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-success">Terima</button>
                </form>
            </div>
            <div class="col-3">
                <a class="btn btn-info" href="<?php echo e(url('admin/verifycompany/'.$value->id.'/edit')); ?>">Lihat</a>
            </div>
            <div class="col-3">
                <form action="<?php echo e(url('admin/verifycompany/'.$value->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="DELETE">
                    <button class="btn btn-danger">Tolak</button>
                </form>
            </div>
        </div>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobqo repo\TIFB_Kelompok_6_Web_Framework\Jobqo-admin\resources\views/_AdminPage/permohonan/v_company.blade.php ENDPATH**/ ?>