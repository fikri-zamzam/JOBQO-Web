<nav class="navbar navbar-expand-lg navbar-dark py-4">
    <a href="<?php echo e(url('/')); ?>" class="navbar-brand">
        <img src="<?php echo e(url('images/logo.png')); ?>" alt="">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav gap-2">
            <li class="nav-item">
                <a href="#" class="nav-link">Pelajari</a>
            </li>
            <hr class="navbar-inline">
            <li class="nav-item me-lg-3">
                <a href="/logout-user" class="nav-link">FAQ</a>
            </li>

            <?php if($isLogin == "true"): ?>
                <li class="nav-item me-lg-3">
                    <a href="" class="nav-link"><?php echo e(Auth::user()->name); ?></a>
                </li>
            <?php else: ?>
                <li class="nav-item me-lg-3">
                    <a href="<?php echo e(url('/login')); ?>" class="nav-link btn btn-yellow">Masuk</a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(url('/register')); ?>" class="nav-link btn btn-outline-yellow">Daftar</a>
                </li>
            <?php endif; ?>

        </ul>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\jobqo repo\TIFB_Kelompok_6_Web_Framework\Jobqo-admin\resources\views/_PekerjaPage/includes/navbar.blade.php ENDPATH**/ ?>