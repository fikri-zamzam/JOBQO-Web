
<link rel="stylesheet" href="<?php echo e(asset('public_assets/vendors/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public_assets/vendors/boxicons-2.1.2/css/boxicons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public_assets/styles/style.css')); ?>">
<?php /**PATH C:\xampp\htdocs\jobqo repo\TIFB_Kelompok_6_Web_Framework\Jobqo-admin\resources\views/_PekerjaPage/includes/style.blade.php ENDPATH**/ ?>