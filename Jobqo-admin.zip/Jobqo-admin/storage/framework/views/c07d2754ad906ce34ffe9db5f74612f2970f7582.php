

<?php $__env->startSection('content'); ?>
<section class="register">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-md-7">
                <div class="register-area text-center">
                    <h2 class="section-title text-white">
                        Masuk <span>Sebagai Kandidat</span>
                    </h2>
                    <p class="section-description">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse tempus eget leo sed
                        faucibus. In pretium ante.
                    </p>

                    <form action="<?php echo e(url('/loginPost')); ?>" method="POST" class="register-form">
                        <?php echo csrf_field(); ?>
                        <input type="email" class="form-control" placeholder="Email" name="email">
                        <input type="password" class="form-control" placeholder="Password" name="password">

                        <button class="btn btn-yellow w-100 d-block" type="submit">Login</button>
                        <p class="section-description mt-3">Belum punya akun? <a href="/register" class="text-orange">Daftar sekarang juga!</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <img src="<?php echo e(url('images/icons/layer-blur-2.svg')); ?>" alt="" class="layer-blur-1">
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_PekerjaPage.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobqo repo\TIFB_Kelompok_6_Web_Framework\Jobqo-admin\resources\views/_PekerjaPage/pages/login.blade.php ENDPATH**/ ?>