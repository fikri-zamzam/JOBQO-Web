

<?php $__env->startSection('content'); ?>
    
<a href="<?php echo e(url('admin/jobs_position/create')); ?>" class="btn btn-primary mt-3"><i class="fa fa-plus-square mr-2"></i>Tambah <?php echo e($title); ?></a>
<table class="table mt-3">
    <thead class="table-dark">
      <th>Nomor</th>
      <th>ID</th>
      <th>Nama Posisi</th>
      <th>Deskripsi</th>
      <th>Aksi</th>
    </thead>
    <tbody>
      <?php $__currentLoopData = $jobs_position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td scope="row"> <?php echo e($key+1); ?> </td>
        <td> <?php echo e($value->id); ?> </td>
        <td> <?php echo e($value->name); ?> </td>
        <td> <?php echo e($value->deskripsi); ?> </td>
        <td>
          <div class="row">
            <div class="col-3">
                <a class="btn btn-info" href="<?php echo e(url('admin/jobs_position/'.$value->id.'/edit')); ?>">Edit</a>
            </div>
            <div class="col-3">
                <form action="<?php echo e(url('admin/jobs_position/'.$value->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="DELETE">
                    <button class="btn btn-danger">Hapus</button>
                </form>
            </div>
        </div>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobqo repo\TIFB_Kelompok_6_Web_Framework\Jobqo-admin\resources\views/_AdminPage/jobs/jobs_position/index.blade.php ENDPATH**/ ?>