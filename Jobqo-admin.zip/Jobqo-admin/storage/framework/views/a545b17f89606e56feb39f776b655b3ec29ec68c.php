

<?php $__env->startSection('CheckDoc_content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <form action="<?php echo e(route('step-two-post')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header">Step 2: Formulir Perusahaan</div>
  
                    <div class="card-body">
  
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
  
                            <div class="form-group row">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="idName">Nama Perusahaan <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                  <input type="text" id="idName" name="name_company" required="required" value="<?php echo e(old('name_company')); ?>" class="form-control  ">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="idEmail" class="col-form-label col-md-3 col-sm-3 label-align">Email</label>
                                <div class="col-md-6 col-sm-6 ">
                                  <input id="idEmail" class="form-control col" type="email" value="<?php echo e(old('email')); ?>" name="email">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="idAlamat">Alamat <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 ">
                                  <textarea class="form-control" name="alamat" id="idAlamat" ><?php echo e(old('alamat')); ?></textarea>
                                </div>
                              </div>
                              <div class="form-group row">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="idKodepos">Kode Pos <span class="required">*</span>
                                </label>
                                <div class="col-md-2 col-sm-6 ">
                                  <input type="text" id="idKodepos" name="kode_pos" required="required" value="<?php echo e(old('kode_pos')); ?>" class="form-control " maxlength="6">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="idContact">Contact Perusahaan <span class="required">*</span>
                                </label>
                                <div class="col-md-3 col-sm-6 ">
                                  <input type="text" id="idContact" name="contact" required="required" value="<?php echo e(old('contact')); ?>" class="form-control " maxlength="15">
                                </div>
                              </div>
  
                              <div class="form-group row">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="idContact">Bidang Perusahaan <span class="required">*</span>
                                </label>
                                <div class="col-md-3 col-sm-6 ">
                                  <select class="form-control" id="idSector" name="company_sector_id">
                                    <?php $__currentLoopData = $CompanySector; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sector->id); ?>"><?php echo e($sector->nameSector); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                </div>
                              </div>
  
                              <div class="form-group row">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="idContact">Jenis Perusahaan <span class="required">*</span>
                                </label>
                                <div class="col-md-4 col-sm-6 ">
                                  <select class="form-control" id="idSector" name="company_type_id">
                                    <?php $__currentLoopData = $CompanyType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type->id); ?>"><?php echo e($type->nameType); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                </div>
                              </div>
  
                              
  
                              <div class="form-group row">
                                <label class="col-form-label col-md-3 col-sm-3 label-align" for="idWebsite">Website Perusahaan <span class="required">*</span>
                                </label>
                                <div class="col-md-4 col-sm-6 ">
                                  <input type="text" id="idWebsite" name="website" required="required" value="<?php echo e(old('website')); ?>" class="form-control  ">
                                </div>
                              </div>
  
                    </div>
                    <div class="card-footer">
                        <div class="row">
                            <div class="col-md-10 text-left">
                                <a href="<?php echo e(route('step-one-show')); ?>" class="btn btn-danger pull-right">Previous</a>
                            </div>
                            <div class="col-md-1 text-right">
                                <button type="submit" class="btn btn-primary">Finish</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_HRDPage.dashboard.confirmDoc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobqo repo\TIFB_Kelompok_6_Web_Framework\Jobqo-admin\resources\views/_HRDPage/dashboard/step-two.blade.php ENDPATH**/ ?>