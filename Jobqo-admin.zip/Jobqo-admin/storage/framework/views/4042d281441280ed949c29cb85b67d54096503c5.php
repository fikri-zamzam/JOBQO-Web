

<?php $__env->startSection('content'); ?>

<div class="col-12">
    <form action="<?php echo e(url('admin/jobs/'.$model->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PATCH">
        <div class="form-group mt-2">
            <label for="exampleFormControlInput1">Nama Pekerjaan</label>
            <input type="text" class="form-control" name="name_job" 
                    placeholder="Nama Pekerjaan" value="<?php echo e(old('name_job',$model->name_job)); ?>" >
        </div>
        <?php $__errorArgs = ['name_job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="form-group mt-2">
            <label for="exampleFormControlInput1">Deskripsi Pekerjaan</label>
            <input type="text" class="form-control" name="desk_job" 
                    placeholder="Deskripsi Pekerjaan" value="<?php echo e(old('desk_job',$model->desk_job)); ?>">
        </div>
        <?php $__errorArgs = ['desk_job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="form-group mt-2">
            <label for="exampleFormControlInput1">Gaji</label>
            <select class="form-control" id="idsalary" name="salaries_id">
                <?php $__currentLoopData = $Salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s->id); ?>" <?php echo e((($model->salaries_id == $s->id ) ? "selected" : "")); ?>>
                    <?php echo e($s->range_salary); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php $__errorArgs = ['gaji'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="form-group">
            <label for="idcompany">Asal Pekerjaan</label>
            <select class="form-control" id="idcompany" name="company_id">
            <?php $__currentLoopData = $Companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($com->id); ?>" <?php echo e((($model->company_id == $com->id ) ? "selected" : "")); ?>><?php echo e($com->name_company); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="idcategory">Kategori Pekejaan</label>
            <select class="form-control" id="idcategory" name="job_category_id">
            <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($ctg->id); ?>" <?php echo e((($model->job_category_id == $ctg->id ) ? "selected" : "")); ?> ><?php echo e($ctg->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="idposition">Posisi Pekejaan</label>
            <select class="form-control" id="idposition" name="job_position_id">
            <?php $__currentLoopData = $Positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pst->id); ?>" <?php echo e((($model->job_position_id == $pst->id ) ? "selected" : "")); ?> ><?php echo e($pst->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group mt-2">
            <label for="exampleFormControlInput1">Persyaratan Pekerjaan</label>
            <p>
                <input id="x" type="hidden" name="job_requirement" value="<?php echo e(old('job_requirement',$model->job_requirement)); ?>" />
                <trix-editor input="x" class="trix-content"></trix-editor>
            </p>
        </div>
        <?php $__errorArgs = ['job_requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="form-group mt-3">
            <button class="btn btn-primary" type="submit">Edit Perubahan</button>
            <a href="/jobs">
                <button class="btn btn-danger" type="button" name="kembali">Kembali</button>
            </a>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobqo repo\TIFB_Kelompok_6_Web_Framework\Jobqo-admin\resources\views/_AdminPage/jobs/jobs_main/edit.blade.php ENDPATH**/ ?>