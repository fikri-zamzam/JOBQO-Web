

<?php $__env->startSection('content'); ?>

<div class="col-12">
    <form action="<?php echo e(url('admin/jobs_salary/'.$model->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PATCH">
        <div class="form-group mt-2">
            <label for="exampleFormControlInput1">Range gaji</label>
            <input type="text" class="form-control" name="range_salary" required
                    placeholder="Contoh : 2500000 - 5000000" value="<?php echo e($model->range_salary); ?>" >
        </div>
        <div class="form-group mt-2">
            <label for="exampleFormControlInput1">Deskripsi</label>
            <input type="text" class="form-control" name="deskripsi" required
                    placeholder="Deskripsi" value="<?php echo e($model->deskripsi); ?>" >
        </div>
        <div class="form-group mt-3">
            <button class="btn btn-primary" type="submit">Edit Perubahan</button>
            <a href="/jobs_type">
                <button class="btn btn-danger" type="button" name="kembali">Kembali</button>
            </a>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jobqo repo\TIFB_Kelompok_6_Web_Framework\Jobqo-admin\resources\views/_AdminPage/jobs/jobs_salary/edit.blade.php ENDPATH**/ ?>